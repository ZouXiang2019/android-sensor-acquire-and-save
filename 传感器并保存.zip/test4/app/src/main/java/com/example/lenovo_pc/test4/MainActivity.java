package com.example.lenovo_pc.test4;


import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.text.SimpleDateFormat;



//获取当前时间

/*public class MainActivity extends AppCompatActivity {

    private TextView tv;
    private SensorManager sensor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv=(TextView)findViewById(R.id.tv);
        SensorManager sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        Sensor sensorg = sensor.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        /*List<Sensor> list=sensor.getSensorList(Sensor.TYPE_ALL);
        tv.append("number:"+list.size()+"\n");
        for(Sensor sen:list){
            String msg="类型："+sen.getType()+"\n名字："+sen.getName()+"\n版本："+sen.getVersion()+"\n";
            switch(sen.getType()){
                case Sensor.TYPE_ACCELEROMETER:
                    tv.append("加速度传感器:\n"+msg);
                    break;
                case Sensor.TYPE_AMBIENT_TEMPERATURE:
                    tv.append("温度传感器:\n"+msg);
                    break;
                case Sensor.TYPE_GRAVITY:
                    tv.append("重力传感器:\n"+msg);
                    break;
                case Sensor.TYPE_GYROSCOPE:
                    tv.append("陀螺仪传感器:\n"+msg);
                    break;
                case Sensor.TYPE_LIGHT:
                    tv.append("光线传感器:\n"+msg);
                    break;
                    default:
                        break;
            }
        }
    }
    @Override
    public void onSensorChanged(SensorEvent event){
        if(event.sensor.getType()==Sensor.TYPE_GYROSCOPE){
            showInfo("x:"+event.values[0]+"\ny:"+event.values[1]+"\nz:"+event.values[2]+"\n");
    }

    private void showInfo(String info){
        Log.d(info);
        }
    }
}*/
//public class MainActivity extends AppCompatActivity implements SensorEventListener,View.OnClickListener {
    public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private TextView mtextViewmagn;
/*
    private TextView tv;
    private TextView mtextViewacc;
    private TextView mtextViewgyro;
    private TextView mtextViewmagn;
    private TextView mtextViewgra;
    private TextView mtextViewtemp;
    private TextView mtextViewlight;
    private TextView mtextViewori;
    private TextView mtextViewgy;
    private TextView mtextViewgz;
    private TextView mtextView1;
    private TextView mtextView2;
    private TextView mtextView3;
    private TextView mtextView4;
    private TextView mtextView5;
    private TextView mtextView6;
    private TextView mtextView7;
    private TextView mtextView8;
    private TextView mtextView9;
    private TextView mtextView10;
    private TextView mtextView11;
    private TextView mtextView12;
    private TextView mtextView13;
    private TextView mtextView14;
    private TextView mtextView15;*/

    private SensorManager sm;
    private static final String TAG = "sensor";

    private Button stopbutton;
    private int stopflag = 1;

    //private String fileName = "test.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //moveTaskToBack(true);

        stopbutton = (Button) findViewById(R.id.buttonofstop);
        stopbutton.setOnClickListener(this);

        //tv=(TextView)findViewById(R.id.tv);
        //tv.setMovementMethod(ScrollingMovementMethod.getInstance());//设置textview可以滑动
        //tv.setScrollbarFadingEnabled(false);//设置scrollbar一直显示

        //SensorManager sensor = (SensorManager) getSystemService(SENSOR_SERVICE);
        //List<Sensor> list=sensor.getSensorList(Sensor.TYPE_ALL);

        //tv.append("number of sensors: "+list.size()+"\n\n");
        /*
        for(Sensor sen:list){
            String msg="类型："+sen.getType()+"\n名字："+sen.getName()+"\n\n";
            tv.append(msg);
        }*/
        //Log.i("jsdj","—–TEST-BUNDLE——" );
        //iniView();
    }

    @Override
    public void onClick(View v) {
        mtextViewmagn=(TextView)findViewById(R.id.textViewmagn);
        if(stopflag == 0) {stopflag = 1; Log.e("CLICK","STOP"); mtextViewmagn.setText("Stopped");}
        else {stopflag = 0; Log.e("CLICK","START");mtextViewmagn.setText("Running");}

        switch (stopflag)
        {
            case 0:
                Intent startIntent = new Intent(this, MyService.class);
                startService(startIntent);
                break;
            case 1:
                Intent stopIntent = new Intent(this, MyService.class);
                stopService(stopIntent);
                break;
            default:
                break;

        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        /*setSensor();
        SensorManager mSensorManager;
        List<Sensor> sensorList;
        // 实例化传感器管理者
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // 得到设置支持的所有传感器的List
        sensorList = mSensorManager.getSensorList(Sensor.TYPE_ALL);
        List<String> sensorNameList = new ArrayList<String>();
        for (Sensor sensor : sensorList) {
            Log.d(TAG, "onResume: "+sensor.getName());
        }*/
    }
/*
    public void iniView() {
                    //mtextViewacc = (TextView) findViewById(R.id.textViewacc);
                    //mtextViewgyro = (TextView) findViewById(R.id.textViewgyro);
                    mtextViewmagn = (TextView) findViewById(R.id.textViewmagn);
                    //mtextViewgra = (TextView) findViewById(R.id.textViewgra);
                    //mtextViewlight = (TextView) findViewById(R.id.textViewlight);
                    //mtextViewtemp = (TextView) findViewById(R.id.textViewtemp);
                    //mtextViewori = (TextView) findViewById(R.id.textViewori);
                    //mtextViewgy = (TextView) findViewById(R.id.textViewgy);
                    //mtextViewgz = (TextView) findViewById(R.id.textViewgz);
                    //mtextView1 = (TextView) findViewById(R.id.textView1);
                    //mtextView2 = (TextView) findViewById(R.id.textView2);
                    //mtextView3 = (TextView) findViewById(R.id.textView3);
                    //mtextView4 = (TextView) findViewById(R.id.textView4);
                    //mtextView5 = (TextView) findViewById(R.id.textView5);
                    //mtextView6 = (TextView) findViewById(R.id.textView6);
                    //mtextView7 = (TextView) findViewById(R.id.textView7);
                    //mtextView8 = (TextView) findViewById(R.id.textView8);
                    //mtextView9 = (TextView) findViewById(R.id.textView9);
                    //mtextView10 = (TextView) findViewById(R.id.textView10);
                    //mtextView11 = (TextView) findViewById(R.id.textView11);
                    //mtextView12 = (TextView) findViewById(R.id.textView12);
                    //mtextView13 = (TextView) findViewById(R.id.textView13);
                    //mtextView14 = (TextView) findViewById(R.id.textView14);
                    //mtextView15 = (TextView) findViewById(R.id.textView15);
                }
*/
/*
                public void setSensor() {
                    //创建一个SensorManager来获取系统的传感器服务
                    sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
                    /*
                     * 最常用的一个方法 注册事件
                     * 参数1 ：SensorEventListener监听器
                     * 参数2 ：Sensor 一个服务可能有多个Sensor实现，此处调用getDefaultSensor获取默认的Sensor
                     * 参数3 ：模式 可选数据变化的刷新频率，多少微秒取一次。
                     * */
/*
                    //加速度传感器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为磁场传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为方向传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为陀螺仪传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为重力传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_GRAVITY), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为线性加速度传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为温度传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_TEMPERATURE), SensorManager.SENSOR_DELAY_NORMAL);
                    Sensor tempertureSensor = sm.getDefaultSensor(Sensor.TYPE_PRESSURE);
//        if (tempertureSensor == null) {
//            Toast.makeText(this, "你的设备不支持该功能", 0).show();
//        }
                    // 为光传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_LIGHT), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为距离传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_PROXIMITY), SensorManager.SENSOR_DELAY_NORMAL);
                    // 为压力传感器注册监听器
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_PRESSURE), SensorManager.SENSOR_DELAY_NORMAL);
                    // 计步统计
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER), SensorManager.SENSOR_DELAY_NORMAL);
                    // 单次计步
                    sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR), SensorManager.SENSOR_DELAY_NORMAL);
                }
*/
/*
                @Override
                public void onSensorChanged(SensorEvent sensorEvent) {
                    if (stopflag == 0) {
                        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                            float X_lateral = sensorEvent.values[0];
                float Y_longitudinal = sensorEvent.values[1];
                float Z_vertical = sensorEvent.values[2];
                //mtextViewacc.setText("\n加速度计数据：\n" + "x : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n");
                //mtextViewy.setText("y:"+Y_longitudinal + "");
                //mtextViewz.setText("z:"+Z_vertical + "");
                SimpleDateFormat   formatter   =   new   SimpleDateFormat   ("HH:mm:ss");
                Date curDate =  new Date(System.currentTimeMillis());
                String timenow = formatter.format(curDate);

                //String msg = "加速度计数据：\n" + "x : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n";
               // Log.d("jsdj", msg);
                String dataofjsdj = timenow + "  "+"x : " + X_lateral + "  " + "y : " + Y_longitudinal + " " + "z : " + Z_vertical + "\n";
                //writeData(dataofjsdj);
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                float X_lateral = sensorEvent.values[0];
                float Y_longitudinal = sensorEvent.values[1];
                float Z_vertical = sensorEvent.values[2];
                mtextViewmagn.setText("磁场强度:\nx : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n");
                String msg = "数据：\n" + "x : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n";
                Log.i("jsdj","—–TEST-BUNDLE——" + msg);
                //mtextView2.setText("y轴的磁场强度\n"+ Y_longitudinal );
                //mtextView3.setText("z轴的磁场强度\n"+ Z_vertical );
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_ORIENTATION) {
                float X_lateral = sensorEvent.values[0];
                float Y_longitudinal = sensorEvent.values[1];
                float Z_vertical = sensorEvent.values[2];
                //mtextViewori.setText("绕z轴转过的角度：" + X_lateral + "\n绕x轴转过的角度：" + Y_longitudinal + "\n绕y轴转过的角度：" + Z_vertical + "\n");
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
                //需要将弧度转为角度
                float X = (float) Math.toDegrees(sensorEvent.values[0]);
                float Y = (float) Math.toDegrees(sensorEvent.values[1]);
                float Z = (float) Math.toDegrees(sensorEvent.values[2]);
                //float X = sensorEvent.values[0];
                //float Y = sensorEvent.values[1];
                //float Z = sensorEvent.values[2];
                //mtextViewgyro.setText("陀螺仪数据：\n绕x轴转过的角度：" + X + "°\n" + "绕y轴转过的角度：" + Y + "°\n" + "绕z轴转过的角度：" + Z + "°\n");
                //mtextView8.setText("绕y轴转过的角速度:"+ Y );
                //mtextView9.setText("绕y轴转过的角速度:"+ Y  );
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_GRAVITY) {
                float X = sensorEvent.values[0];
                float Y = sensorEvent.values[1];
                float Z = sensorEvent.values[2];
                //mtextViewgra.setText("重力加速度：\n x方向：" + X + "\n y方向：" + Y + "\n z方向：" + Z + "\n");
                //mtextViewgy.setText("Y方向的重力加速度\n"+ Y );
                //mtextViewgz.setText("Z方向的重力加速度\n"+ Z );
            }/*
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){
            float X = sensorEvent.values[0];
            float Y = sensorEvent.values[1];
            float Z = sensorEvent.values[2];
            mtextViewlx.setText("x方向的线性加速度\n"+ X );
            mtextViewly.setText("Y方向的线性加速度\n"+ Y );
            mtextViewlz.setText("Z方向的线性加速度\n"+ Z );
        }*else if (sensorEvent.sensor.getType() == Sensor.TYPE_TEMPERATURE) {
                float X = sensorEvent.values[0];
                //mtextViewtemp.setText("温度为：" + X + "\n");
            } else if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT) {
                float X = sensorEvent.values[0];
                //mtextViewlight.setText("光强度为：" + X + "\n");
            }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY){
            float X = sensorEvent.values[0];
            mtextView12.setText("距离为"+ X );
        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_PRESSURE){
            float X = sensorEvent.values[0];
            mtextView13.setText("压强为"+ X );
        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_STEP_COUNTER){
            float X = sensorEvent.values[0];
            mtextView14.setText("COUNTER："+ X );
        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_STEP_DETECTOR){
            float X = sensorEvent.values[0];
            mtextView15.setText("DECTOR："+ X );
        }
        }
    }*/
/*
    //&#x5411;&#x6307;&#x5b9a;&#x7684;&#x6587;&#x4ef6;&#x4e2d;&#x5199;&#x5165;&#x6307;&#x5b9a;&#x7684;&#x6570;&#x636e;
       public void writeFileData(String filename, String content){

          try {
            FileOutputStream fos = this.openFileOutput(filename, MODE_WORLD_READABLE);//&#x83b7;&#x5f97;FileOutputStream
                         //&#x5c06;&#x8981;&#x5199;&#x5165;&#x7684;&#x5b57;&#x7b26;&#x4e32;&#x8f6c;&#x6362;&#x4e3a;byte&#x6570;&#x7ec4;
                         byte[]  bytes = content.getBytes();
                         fos.write(bytes);//&#x5c06;byte&#x6570;&#x7ec4;&#x5199;&#x5165;&#x6587;&#x4ef6;
                         //&#x5173;&#x95ed;&#x6587;&#x4ef6;&#x8f93;&#x51fa;&#x6d41;
                         fos.close();
                     }
                     catch (Exception e) {
                        e.printStackTrace();
                        }
       }


private void writeData(String str) {
    String filePath = "/data/data/";
    String fileName = "data.txt";
    writeTxtToFile(str, filePath, fileName);

}

    // 将字符串写入到文本文件中
    private void writeTxtToFile(String strcontent, String filePath, String fileName) {
        //生成文件夹之后，再生成文件，不然会出错
        //makeFilePath(filePath, fileName);

        //String strFilePath = filePath + fileName;
        // 每次写入时，都换行写
        String strContent = strcontent + "\r\n";
        writeinsdcard(strContent);
    }

//生成文件

    private File makeFilePath(String filePath, String fileName) {
        File file = null;
        makeRootDirectory(filePath);
        try {
            file = new File(filePath + fileName);
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return file;
    }

//生成文件夹

    private static void makeRootDirectory(String filePath) {
        File file = null;
        try {
            file = new File(filePath);
            if (!file.exists()) {
                file.mkdir();
            }
        } catch (Exception e) {
            Log.i("error:", e + "");
        }
    }

  public void writeinsdcard(String msg){

      FileOutputStream fos = null;
      String text = msg;
      boolean success = true;
      try {
          fos = new FileOutputStream(Environment.getExternalStorageDirectory().getPath() + "/m.txt",true);
          fos.write(text.getBytes("utf-8"));
          fos.flush();
      } catch (IOException e) {
          success = false;
          e.printStackTrace();
      } finally {
          if(fos != null){
              try {
                  fos.close();
                  fos = null;
              } catch (IOException e) {
                  e.printStackTrace();
              }
          }
      }
      //Toast.makeText(MainActivity.this, success == true ? "写入sdcard文件成功" : "写入sdcard文件失败", 0).show();

  }*/
    //复写onAccuracyChanged方法

    //@Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        Log.i(TAG, "onAccuracyChanged");
    }

    @Override
    public void onPause() {
        //sm.unregisterListener(this);
        super.onPause();
    }


}
