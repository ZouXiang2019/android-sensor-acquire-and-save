package com.example.lenovo_pc.test4;


import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Environment;
import android.os.IBinder;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.widget.TextView;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.lang.Math.abs;


public  class MyService extends Service implements SensorEventListener {

    public static final String TAG = "MyService";
    private SensorManager sm;
    private TextView tv;

    //创建服务时调用
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
    }

    //服务执行的操作
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        SensorManager sensor = (SensorManager) getSystemService(SENSOR_SERVICE);
        List<Sensor> list=sensor.getSensorList(Sensor.TYPE_ALL);
        Log.d(TAG, "onStartCommand");
        setSensor();
        SensorManager mSensorManager;
        List<Sensor> sensorList;
        // 实例化传感器管理者
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        // 得到设置支持的所有传感器的List
        sensorList = mSensorManager.getSensorList(Sensor.TYPE_ALL);
        for(Sensor sen:list){
            String msg="类型："+sen.getType()+"\n名字："+sen.getName()+"\n\n";
            Log.d("Sensor: ",msg);
        }
        List<String> sensorNameList = new ArrayList<String>();
        return super.onStartCommand(intent, flags, startId);
    }

    //销毁服务时调用
    @Override
    public void onDestroy() {
        sm.unregisterListener(this);
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public void setSensor() {
        //创建一个SensorManager来获取系统的传感器服务
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        /*
         * 最常用的一个方法 注册事件
         * 参数1 ：SensorEventListener监听器
         * 参数2 ：Sensor 一个服务可能有多个Sensor实现，此处调用getDefaultSensor获取默认的Sensor
         * 参数3 ：模式 可选数据变化的刷新频率，多少微秒取一次。
         * */
        //加速度传感器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL);
        // 为磁场传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD), SensorManager.SENSOR_DELAY_FASTEST);
        // 为方向传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ORIENTATION), SensorManager.SENSOR_DELAY_NORMAL);
        // 为陀螺仪传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_NORMAL);
        // 为重力传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_GRAVITY), SensorManager.SENSOR_DELAY_NORMAL);
        // 为线性加速度传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION), SensorManager.SENSOR_DELAY_NORMAL);
        // 为温度传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_TEMPERATURE), SensorManager.SENSOR_DELAY_NORMAL);
        Sensor tempertureSensor = sm.getDefaultSensor(Sensor.TYPE_PRESSURE);
//        if (tempertureSensor == null) {
//            Toast.makeText(this, "你的设备不支持该功能", 0).show();
//        }
        // 为光传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_LIGHT), SensorManager.SENSOR_DELAY_NORMAL);
        // 为距离传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_PROXIMITY), SensorManager.SENSOR_DELAY_NORMAL);
        // 为压力传感器注册监听器
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_PRESSURE), SensorManager.SENSOR_DELAY_NORMAL);
        // 计步统计
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_STEP_COUNTER), SensorManager.SENSOR_DELAY_NORMAL);
        // 单次计步
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR), SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

            if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                float X_lateral = sensorEvent.values[0];
                float Y_longitudinal = sensorEvent.values[1];
                float Z_vertical = sensorEvent.values[2];
                //mtextViewacc.setText("\n加速度计数据：\n" + "x : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n");
                //mtextViewy.setText("y:"+Y_longitudinal + "");
                //mtextViewz.setText("z:"+Z_vertical + "");


                //String msg = "加速度计数据：\n" + "x : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n";
                // Log.d("jsdj", msg);
                String dataofjsdj = "x : " + X_lateral + "  " + "y : " + Y_longitudinal + " " + "z : " + Z_vertical + "\n";

            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                float X_lateral = sensorEvent.values[0];
                float Y_longitudinal = sensorEvent.values[1];
                float Z_vertical = sensorEvent.values[2];
                float B = (X_lateral)*(X_lateral)+(Y_longitudinal)*Y_longitudinal+(Z_vertical)*(Z_vertical);
                //mtextViewmagn.setText("磁场强度:\nx : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n");
                SimpleDateFormat formatter   =   new   SimpleDateFormat   ("HH:mm:ss");
                Date curDate =  new Date(System.currentTimeMillis());
                String timenow = formatter.format(curDate);
                String magnetdata = "t :"+timenow+"\n"+ "x : " + X_lateral + "\n" + "y : " + Y_longitudinal + "\n" + "z : " + Z_vertical + "\n";
                Log.i("maget", ""+B);

                //writeData(magnetdata);
                //mtextView2.setText("y轴的磁场强度\n"+ Y_longitudinal );
                //mtextView3.setText("z轴的磁场强度\n"+ Z_vertical );
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_ORIENTATION) {
                float X_lateral = sensorEvent.values[0];
                float Y_longitudinal = sensorEvent.values[1];
                float Z_vertical = sensorEvent.values[2];
                //mtextViewori.setText("绕z轴转过的角度：" + X_lateral + "\n绕x轴转过的角度：" + Y_longitudinal + "\n绕y轴转过的角度：" + Z_vertical + "\n");
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
                //需要将弧度转为角度
                float X = (float) Math.toDegrees(sensorEvent.values[0]);
                float Y = (float) Math.toDegrees(sensorEvent.values[1]);
                float Z = (float) Math.toDegrees(sensorEvent.values[2]);
                //float X = sensorEvent.values[0];
                //float Y = sensorEvent.values[1];
                //float Z = sensorEvent.values[2];
                //mtextViewgyro.setText("陀螺仪数据：\n绕x轴转过的角度：" + X + "°\n" + "绕y轴转过的角度：" + Y + "°\n" + "绕z轴转过的角度：" + Z + "°\n");
                //mtextView8.setText("绕y轴转过的角速度:"+ Y );
                //mtextView9.setText("绕y轴转过的角速度:"+ Y  );
            }
            else if (sensorEvent.sensor.getType() == Sensor.TYPE_GRAVITY) {
                float X = sensorEvent.values[0];
                float Y = sensorEvent.values[1];
                float Z = sensorEvent.values[2];
                //mtextViewgra.setText("重力加速度：\n x方向：" + X + "\n y方向：" + Y + "\n z方向：" + Z + "\n");
                //mtextViewgy.setText("Y方向的重力加速度\n"+ Y );
                //mtextViewgz.setText("Z方向的重力加速度\n"+ Z );
            }/*
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_LINEAR_ACCELERATION){
            float X = sensorEvent.values[0];
            float Y = sensorEvent.values[1];
            float Z = sensorEvent.values[2];
            mtextViewlx.setText("x方向的线性加速度\n"+ X );
            mtextViewly.setText("Y方向的线性加速度\n"+ Y );
            mtextViewlz.setText("Z方向的线性加速度\n"+ Z );
        }*/ else if (sensorEvent.sensor.getType() == Sensor.TYPE_TEMPERATURE) {
                float X = sensorEvent.values[0];
                //mtextViewtemp.setText("温度为：" + X + "\n");
            } else if (sensorEvent.sensor.getType() == Sensor.TYPE_LIGHT) {
                float X = sensorEvent.values[0];
                //mtextViewlight.setText("光强度为：" + X + "\n");
            }/*
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_PROXIMITY){
            float X = sensorEvent.values[0];
            mtextView12.setText("距离为"+ X );
        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_PRESSURE){
            float X = sensorEvent.values[0];
            mtextView13.setText("压强为"+ X );
        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_STEP_COUNTER){
            float X = sensorEvent.values[0];
            mtextView14.setText("COUNTER："+ X );
        }
        else if(sensorEvent.sensor.getType() == Sensor.TYPE_STEP_DETECTOR){
            float X = sensorEvent.values[0];
            mtextView15.setText("DECTOR："+ X );
        }*/
        }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    private void writeData(String msg){

        FileOutputStream fos = null;
        String text = msg+"\r\n";
        boolean success = true;
        try {
            fos = new FileOutputStream(Environment.getExternalStorageDirectory().getPath() + "/data_of_magnet.txt",true);
            fos.write(text.getBytes("utf-8"));
            fos.flush();
        } catch (IOException e) {
            success = false;
            e.printStackTrace();
        } finally {
            if(fos != null){
                try {
                    fos.close();
                    fos = null;
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        //Toast.makeText(MainActivity.this, success == true ? "写入sdcard文件成功" : "写入sdcard文件失败", 0).show();
    }
}
